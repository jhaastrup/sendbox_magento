<?php
namespace Sendbox\Sendboxshipping\Block\Adminhtml\Order\View;
class Sendbox extends \Magento\Backend\Block\Template
{

} 